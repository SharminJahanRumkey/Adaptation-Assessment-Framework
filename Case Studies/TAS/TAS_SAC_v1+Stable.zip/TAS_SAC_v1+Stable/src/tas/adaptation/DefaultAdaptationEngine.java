package tas.adaptation;

public class DefaultAdaptationEngine implements AdaptationEngine {

    @Override
    public void start() {
	// TODO Auto-generated method stub
	
    }

    @Override
    public void stop() {
	// TODO Auto-generated method stub
	
    }
}
