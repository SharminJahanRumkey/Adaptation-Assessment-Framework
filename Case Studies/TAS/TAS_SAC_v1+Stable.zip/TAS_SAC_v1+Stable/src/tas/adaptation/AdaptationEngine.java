/**
 * 
 */
package tas.adaptation;

/**
 * @author yfruan
 * @email ry222ad@student.lnu.se
 *
 */
public interface AdaptationEngine {
    
    public void start();
    
    public void stop();
   
}
