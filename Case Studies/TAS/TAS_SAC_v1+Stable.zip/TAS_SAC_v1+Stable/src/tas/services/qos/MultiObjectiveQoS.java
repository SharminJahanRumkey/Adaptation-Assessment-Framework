package tas.services.qos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import securityawareness.AssessmentComponent;
import securityawareness.ImpactFactor;
import securityawareness.SecurityProfile;
import securityawareness.SecurityProperty;
import service.auxiliary.ServiceDescription;
import service.workflow.AbstractQoSRequirement;


public class MultiObjectiveQoS implements AbstractQoSRequirement {
    private AssessmentComponent assessmentComponent;

    public void initialize()
    {
        ImpactFactor impactFactor0 = new ImpactFactor("dataEncryption", "Cryptographic hashes applied to encrypt data", 1.0);
        ImpactFactor impactFactor1 = new ImpactFactor("dataEncryption", "Non cryptographic hashes applied to data", 0.5);
        ImpactFactor impactFactor2 = new ImpactFactor("dataEncryption", "Plain text", 0.2);
        ImpactFactor impactFactor3 = new ImpactFactor("backUpHistoricData", "Parmanent Backup of historic data", 0.9);
        ImpactFactor impactFactor4 = new ImpactFactor("backUpHistoricData", "Temporary Backup of historic data", 0.5);
        ImpactFactor impactFactor5 = new ImpactFactor("backUpHistoricData", "No backup", 0.2);
        ImpactFactor impactFactor6 = new ImpactFactor("notification", "Notify patient to change patient data", 0.9);
        ImpactFactor impactFactor7 = new ImpactFactor("notification", "No notificationa", 0.2);
        ImpactFactor impactFactor8 = new ImpactFactor("alert", "Delay", 0.2);
        ImpactFactor impactFactor9 = new ImpactFactor("alert", "Disable", 0.0);

        List<ImpactFactor> impactFactors = new ArrayList<ImpactFactor>();
        impactFactors.add(0, impactFactor0);
        impactFactors.add(1, impactFactor1);
        impactFactors.add(2, impactFactor2);
        impactFactors.add(3, impactFactor3);
        impactFactors.add(4, impactFactor4);
        impactFactors.add(5, impactFactor5);
        impactFactors.add(6, impactFactor6);
        impactFactors.add(7, impactFactor7);
        impactFactors.add(8, impactFactor8);
        impactFactors.add(9, impactFactor9);

        SecurityProfile securityProfile = new SecurityProfile("file1", impactFactors);

        this.assessmentComponent = new AssessmentComponent(securityProfile);
    }



    public double utilityCalForQosRequirement(ServiceDescription serviceDescription){
        double fitVal = 0.0;
        double cost = -1.0;
        double reliability = -1.0;
        int index = 0;
        HashMap properties;
        properties = serviceDescription.getCustomProperties();
        cost = (double) properties.get("Cost");
        reliability = 1.0- (double) properties.get("FailureRate");
        fitVal = reliability / cost;
        return fitVal;
    }

    @Override
    public ServiceDescription applyQoSRequirement(List<ServiceDescription> serviceDescriptions,String opName,Object[] params) {
        initialize();
        int index = 0;
        double fitVal;
        double fitnessVal = Double.MIN_VALUE;
        for (int i = 0; i < serviceDescriptions.size(); i++) {
            fitVal = utilityCalForQosRequirement(serviceDescriptions.get(i));
            if(fitVal >= fitnessVal)
            {
                fitnessVal = fitVal;
                index = i;

                if(serviceDescriptions.get(i).getServiceType().equals("AlarmService")) {
                    System.out.println("Service Name: " + serviceDescriptions.get(i).getServiceName() +
                            " {Cost, Reliablity,  fitness} = { " + serviceDescriptions.get(i).getCustomProperties().get("Cost") + ", " +
                            (1.0 - (double) serviceDescriptions.get(i).getCustomProperties().get("FailureRate")) + ", " +
                            fitnessVal + "}");
                }
            }
        }

        if(serviceDescriptions.get(index).getServiceType().equals("AlarmService")) {

            System.out.println("Final Selection: Service Name: " + serviceDescriptions.get(index).getServiceName() +
                    " {Cost, Reliablity, fitness} = { " + serviceDescriptions.get(index).getCustomProperties().get("Cost") + ", " +
                    (1.0 - (double) serviceDescriptions.get(index).getCustomProperties().get("FailureRate")) + ", " +
                    fitnessVal + "}");
        }
        return serviceDescriptions.get(index);
    }
















}
