package tas.services.profiles;

import java.util.HashMap;

public class Attribute {

	public String name;
	public String type;
	public HashMap<Integer,Object> values=new HashMap<>();
}
