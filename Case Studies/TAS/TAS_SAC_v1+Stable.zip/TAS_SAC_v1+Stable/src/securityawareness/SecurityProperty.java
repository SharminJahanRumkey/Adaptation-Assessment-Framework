package securityawareness;

public class SecurityProperty {
    private String concern;
    private String condition;

    public SecurityProperty(String concern, String condition){
        this.concern = concern;
        this.condition = condition;
    }

    public void setConcern(String concern) {
        this.concern = concern;
    }

    public String getConcern() {
        return concern;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getCondition() {
        return condition;
    }


}
