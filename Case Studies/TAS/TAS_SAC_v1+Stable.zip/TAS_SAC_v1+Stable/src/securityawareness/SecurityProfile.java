package securityawareness;

import java.util.List;

public class SecurityProfile {
    private String SACFilePath;
    private List<ImpactFactor> impactFactors;

    public SecurityProfile(String SACFilePath, List<ImpactFactor> impactFactors){
        this.SACFilePath = SACFilePath;
        this.impactFactors = impactFactors;
    }

    public void setSACFilePath(String SACFilePath) {
        this.SACFilePath = SACFilePath;
    }

    public String getSACFilePath() {
        return SACFilePath;
    }

    public void setImpactFactors(List<ImpactFactor> impactFactors) {
        this.impactFactors = impactFactors;
    }

    public List<ImpactFactor> getImpactFactors() {
        return impactFactors;
    }

    public ImpactFactor getImpactFactor(int index) {
        return this.impactFactors.get(index);
    }

    public ImpactFactor getSpecificImpactFactor(String concern, String condition) {
        int index = -1;
        for (int i =0;i < this.impactFactors.size(); i++) {
            if(this.impactFactors.get(i).getConcern().equals(concern) &&
                    this.impactFactors.get(i).getCondition().equals(condition) ) {
                index = i;
                break;
            }
        }
        return this.impactFactors.get(index);
    }
}
