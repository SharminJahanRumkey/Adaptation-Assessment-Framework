package securityawareness;

public class ImpactFactor {
    private String concern;
    private String condition;
    private double impact;

    public ImpactFactor(String concern, String condition, double impact ){
        this.concern = concern;
        this.condition = condition;
        this.impact = impact;
    }

    public void setConcern(String concern) {
        this.concern = concern;
    }

    public String getConcern() {
        return concern;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getCondition() {
        return condition;
    }

    public void setImpact(double impact) {
        this.impact = impact;
    }

    public double getImpact() {
        return impact;
    }


}
