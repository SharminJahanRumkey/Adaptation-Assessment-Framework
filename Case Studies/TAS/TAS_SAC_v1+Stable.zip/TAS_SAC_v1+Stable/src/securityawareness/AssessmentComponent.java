package securityawareness;

import service.auxiliary.ServiceDescription;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AssessmentComponent {
    private double achievementWeight;
    private double satisficingLevel;
    private SecurityProfile securityProfile;

    public AssessmentComponent(SecurityProfile securityProfile){
        this.achievementWeight = 1.0;
        this.satisficingLevel = 1.0;
        this.securityProfile = securityProfile;
    }

    public void setAchievementWeight(double achievementWeight) {
        this.achievementWeight = achievementWeight;
    }

    public double getAchievementWeight() {
        return achievementWeight;
    }

    public void setSatisficingLevel(double satisficingLevel) {
        this.satisficingLevel = satisficingLevel;
    }

    public double getSatisficingLevel() {
        return satisficingLevel;
    }

    public List<SecurityProperty> extractSecurityProperties(ServiceDescription serviceDescription){

        List<SecurityProperty> securityPropertyList = new ArrayList<SecurityProperty>();
        HashMap secProperties;
        secProperties = serviceDescription.getSecurityProperties();
        Integer i =0;

        for (Object index: secProperties.values() ) {
            i = Integer.valueOf(index.toString());
            SecurityProperty securityProperty = new SecurityProperty(this.securityProfile.getImpactFactor(i).getConcern(),
                    this.securityProfile.getImpactFactor(i).getCondition());
            securityPropertyList.add(securityProperty);
        }

        return securityPropertyList;
    }

    public List<ImpactFactor> adaptationOperationManager(List<SecurityProperty> securityProperties){

       List<ImpactFactor> impactFactors = new ArrayList<>();
        double impact = 0.0;
        int n = securityProperties.size();

        for (SecurityProperty securityproperty: securityProperties) {
            for(ImpactFactor impactFactor: this.securityProfile.getImpactFactors())
            {
                if(securityproperty.getConcern().equals(impactFactor.getConcern()) &&
                    securityproperty.getCondition().equals(impactFactor.getCondition()))
                {
                    impactFactors.add(impactFactor);
                }
            }
        }
        return impactFactors;
    }

    public double calculateAchievementWeight(List<ImpactFactor> impactFactors){
        double confidence = -1.0;
        double impact = 0.0;
        int n = impactFactors.size();

        for (ImpactFactor impactfactor: impactFactors ) {
            impact = impact + impactfactor.getImpact();
        }

        confidence = impact/n;
        return confidence;
    }

    public double calculateSatisficingLevel(List<ImpactFactor> impactFactors) {
        double confidence = calculateAchievementWeight(impactFactors);
        return (1.0+ confidence)/2.0;
    }
}
