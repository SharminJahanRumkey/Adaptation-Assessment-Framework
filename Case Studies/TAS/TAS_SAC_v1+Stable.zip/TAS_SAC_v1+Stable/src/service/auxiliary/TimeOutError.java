package service.auxiliary;

/**
 * Responsible for timeout error
 * @author Yifan Ruan (ry222ad@student.lnu.se)
 */
public class TimeOutError {
}
