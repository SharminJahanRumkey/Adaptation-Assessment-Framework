package service.auxiliary;

public class MessageFailed extends TimeOutError{

}
