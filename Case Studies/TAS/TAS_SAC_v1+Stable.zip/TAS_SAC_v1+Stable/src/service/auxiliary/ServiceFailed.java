package service.auxiliary;

public class ServiceFailed extends TimeOutError{

}
