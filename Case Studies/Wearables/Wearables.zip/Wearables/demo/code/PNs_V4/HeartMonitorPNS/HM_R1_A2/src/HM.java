import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.util.List;
import java.util.Random;

public class HM extends JPanel
{

    public static void main(String [] args) {

        JFrame theGUI = new JFrame();
        theGUI.setTitle("Heart Monitor: R1-A2");
        theGUI.setSize(1500, 1000);
        theGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container pane = theGUI.getContentPane();

        HM_R1_A2 panel = new HM_R1_A2(Color.white, 1500, 1000, 100, 150);
        pane.add(panel);

        theGUI.setVisible(true);
    }

}

