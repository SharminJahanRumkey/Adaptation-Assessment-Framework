/**
 * Created by Sharmin on 12/25/2017.
 */
import javax.swing.plaf.PanelUI;
import java.awt.*;
import java.util.*;
import java.util.List;

public class TransitionLogic {
    public int myredflag =0;

    public Output TokenOutput=new Output();

    public String showBlueToken(blueToken B)
    {
        String outputValue = "";
        if(!B.getVisited().isEmpty() || ((B.getVisited().isEmpty() && B.getIDConflict()!=0)) ) {
            //   System.out.println("Blue token value:");

            outputValue = "(" + B.getVisited().toString() + ",[";

            for (vcMatches v : B.getVcMatchesList()) {
                outputValue = outputValue + "(" + v.getIDConflict() + ",";
                for (vcInfo vI : v.getVcInfoList()) {
                    outputValue = outputValue + "(" + vI.getVC() + ", " + vI.getCondition() + ", " + vI.getVcImpact() + "),";
                }
                outputValue = outputValue + v.getConflictPlace() + "," + v.getImpact() + "),";
            }
            outputValue = outputValue + "],[";
            for (vcChanges v : B.getVcChangesList()) {
                outputValue = outputValue + "(" + v.getIDConflict() + ", " + v.getVC() + ", " + v.getImpact() + "),";
            }
            outputValue = outputValue + "]," + B.getIDConflict() + ", " + B.getCount() + ")";
            //  System.out.println(outputValue);
            //  System.out.println("--------------------------------------------");

            TokenOutput.GenerateblueToken(outputValue, "R1-A1");


        }
        return outputValue;
    }

    public String showRedToken(redToken R) {
        //  System.out.println("Red token value:");
        String outputValue = "";
        outputValue=R.getVcInfoList().getVcImpact()+";"+R.getP()+";"+R.getConflictPlacePredominance()+";"+R.getUtilityWeight();
        //System.out.println(outputValue);

        TokenOutput.GenerateredToken(outputValue, "R1-A1");
        return outputValue;
    }




    public int isVisited(blueToken B, Transition T)
    {
        int isVisited=0;
        if(B.getVisited().size()==1 && B.getVisited().contains("Start") && B.getCount()==0) {
            isVisited=0;
        }
        else if(B.getVisited().contains(T.getName())) {
            isVisited=1;
        }
        return isVisited;
    }


    public void generateVCConflicts(blueToken B, List<pinkToken> PList, Transition T)
    {

        for (pinkToken P: PList)
        {
            int IDConflict = B.getIDConflict();
            String VC="";
            String condition="";
            double vcImpact=0.0;
            String conflictPlace="";
            double impact=0.0;
            for (vcChanges t : B.getVcChangesList()) {
                if (t.getVC().equals(P.getVcConditionImpact().getVC())) {

                    VC = P.getVcConditionImpact().getVC();
                    condition = P.getVcConditionImpact().getCondition();
                    vcImpact = P.getVcConditionImpact().getImpact();
                    conflictPlace = T.getName();
                    impact = getConflictWithVCImpact(T, P);
                    vcInfo vcInfo = new vcInfo(VC, condition, vcImpact);
                    List<vcInfo> vcInfos = new ArrayList<vcInfo>();
                    vcInfos.add(vcInfo);
                    vcMatches vcMatches = new vcMatches(IDConflict, vcInfos, conflictPlace, impact);
                    B.getVcMatchesList().add(vcMatches);
                }



            }
        }
    }











    public int hasPreviousConflictWithPlace(blueToken B, Transition T)
    {
        int hasConflict=0;

        for (vcMatches t : B.getVcMatchesList()) {
            if (t.getConflictPlace().equals(T.getName())) {
                hasConflict = 1;
                break;
            }
        }
        return hasConflict;
    }

    public int hasPreviousConflictWithVC(blueToken B, List<pinkToken> PList)
    {

        int hasConflict=0;
        for(pinkToken P: PList) {
            for (vcChanges t : B.getVcChangesList()) {
                if (t.getVC().equals(P.getVcConditionImpact().getVC())) {
                    hasConflict = 1;
                    break;
                }
            }
        }



        return hasConflict;
    }



    public double getConflictWithVCImpact(Transition T,pinkToken  P)
    {
        double impact=1;

        for (vcInfo t : T.getVcInfoList()) {
            if (t.getVC().equals(P.getVcConditionImpact().getVC()) && t.getCondition().equals(P.getVcConditionImpact().getCondition())) {
                impact = t.getVcImpact();
                break;
            }
        }



        return impact;
    }

    public int hasPreviousConflictWithDependentVC(blueToken B, Transition T)
    {
        int hasConflict=0;
        for (vcChanges t : B.getVcChangesList()) {

            for(pathDependency pd: T.getPathDependencyList())
            {
                for (String v: pd.getDependentVCList() )
                {
                    if(v.contains(t.getVC()))
                    {
                        hasConflict=1;
                        break;
                    }
                }
            }
        }
        return hasConflict;
    }

    public int hasConflictWithVC(List<pinkToken> PList, Transition T)
    {
        int hasConflict=0;

        for(pinkToken P: PList) {
            for (vcInfo t : T.getVcInfoList()) {
                if (t.getVC().equals(P.getVcConditionImpact().getVC())) {
                    hasConflict = 1;
                    break;
                }
            }
        }

        return hasConflict;
    }

    public int hasConflictWithDependentVC(List<pinkToken> PList, Transition T)
    {
        int hasConflict=0;
        for(pinkToken P: PList) {
            for (pathDependency t : T.getPathDependencyList()) {
                for (String vc : t.getDependentVCList()) {
                    if (vc.contains(P.getVcConditionImpact().getVC())) {
                        hasConflict = 1;
                        break;
                    }
                }
            }
        }
        return hasConflict;
    }
    public void generateVCMatches(blueToken B, List<pinkToken> PList, Transition T)
    {

        for (pinkToken P: PList)
        {
            int IDConflict = B.getIDConflict();
            String VC="";
            String condition="";
            double vcImpact=0.0;
            String conflictPlace="";
            double impact=0.0;
            for (vcChanges t : B.getVcChangesList()) {
                if (t.getVC().equals(P.getVcConditionImpact().getVC())) {

                    VC = P.getVcConditionImpact().getVC();
                    condition = P.getVcConditionImpact().getCondition();
                    vcImpact = P.getVcConditionImpact().getImpact();
                    conflictPlace = T.getName();
                    impact = getConflictWithVCImpact(T, P);
                    vcInfo vcInfo = new vcInfo(VC, condition, vcImpact);
                    List<vcInfo> vcInfos = new ArrayList<vcInfo>();
                    vcInfos.add(vcInfo);
                    vcMatches vcMatches = new vcMatches(IDConflict, vcInfos, conflictPlace, impact);
                    B.getVcMatchesList().add(vcMatches);
                }



            }
        }
    }

    public void generateVCChanges(blueToken B, List<pinkToken> PList, Transition T)
    {

        int isPrev=0;
        for (pinkToken P: PList) {

            int IDConflict = B.getIDConflict();
            String VC = P.getVcConditionImpact().getVC();
            double vcImpact = P.getVcConditionImpact().getImpact();
            for(vcChanges t: B.getVcChangesList())
            {
                if(t.getVC().equals(P.getVcConditionImpact().getVC()))
                {
                    isPrev=1;
                }
            }
            if(!VC.equals("-1") && isPrev==0) {
                vcChanges vcChanges = new vcChanges(IDConflict, VC, vcImpact);
                B.getVcChangesList().add(vcChanges);
                VC = P.getVcConditionImpact().getVC();
                String condition = P.getVcConditionImpact().getCondition();
                vcImpact = P.getVcConditionImpact().getImpact();
                String  conflictPlace = T.getName();
                double  impact = getConflictWithVCImpact(T, P);
                vcInfo vcInfo = new vcInfo(VC, condition, vcImpact);
                List<vcInfo> vcInfos = new ArrayList<vcInfo>();
                vcInfos.add(vcInfo);
                vcMatches vcMatches = new vcMatches(IDConflict, vcInfos, conflictPlace, impact);
                B.getVcMatchesList().add(vcMatches);
            }


        }
    }

    public void generateRedToken(blueToken B, List<pinkToken> PList, Transition T,List<redToken> redTokenList)
    {
        String VC="";
        String condition="";
        double vcImpact=0.0;
        String conflictPlace="";
        double impact=0.0;
        int count=0;
        double conflicPlaceImpactMultiplier=0.0;
        for (pinkToken P: PList)
        {

            for (vcChanges t : B.getVcChangesList()) {
                if (t.getVC().equals(P.getVcConditionImpact().getVC())) {
                    count = B.getCount() + 1;
                    redTokenList.get(count).setID(count);
                    redTokenList.get(count).setIDconflict(t.getIDConflict());
                    redTokenList.get(count).setConflictPlace(T.getName());
                    redTokenList.get(count).setConflictPlacePredominance(T.getImpactMultiplier());
                    redTokenList.get(count).getShape().setCenterX(615 + count * 10);
                    redTokenList.get(count).getShape().setCenterY(500 + count * 10);
                    redTokenList.get(count).getShape().setVisible(true);

                    VC = P.getVcConditionImpact().getVC();
                    condition = P.getVcConditionImpact().getCondition();
                    vcImpact = P.getVcConditionImpact().getImpact();
                    conflictPlace = T.getName();
                    impact = getConflictWithVCImpact(T, P);
                    conflicPlaceImpactMultiplier=T.getImpactMultiplier();
                    vcInfo vcInfo = new vcInfo(VC, condition, vcImpact);
                    redTokenList.get(count).setVcInfoList(vcInfo);
                    redTokenList.get(count).setP(impact);
                    redTokenList.get(count).setConflictPlace(conflictPlace);
                    redTokenList.get(count).setConflictPlacePredominance(conflicPlaceImpactMultiplier);
                    B.setCount(count);
                    showRedToken(redTokenList.get(count));
                    myredflag =1;
                }

            }
        }
    }

    public void applyRule(blueToken B, List<pinkToken> P, Transition T,List<redToken> redTokenList)
    {

        int isVisited=isVisited(B, T);
        int hasPreviousConflictWithPlace=hasPreviousConflictWithPlace(B,T);
        int hasPreviousConflictWithVC=hasPreviousConflictWithVC(B,P);
        int hasConflictWithVC=hasConflictWithVC(P, T);
        int hasConflictWithDependentVC= hasConflictWithDependentVC(P, T);

        // System.out.println("Blue: isVisited "+isVisited +", hasPreviousConflictWithPlace"+hasPreviousConflictWithPlace+
        //   ", hasPreviousConflictWithVC"+hasPreviousConflictWithVC+", hasConflictWithVC"+hasConflictWithVC+", hasConflictWithDependentVC"+hasConflictWithDependentVC );


        //    if (T.getName() != "Initialize") {
        if (isVisited == 0 && hasPreviousConflictWithVC == 1 && hasConflictWithVC == 1) {

            B.getVisited().add(T.getName());
            int IDConflict = B.getIDConflict() + 1;
            generateVCMatches(B, P, T);

            generateVCChanges(B,P,T);


            B.setIDConflict(IDConflict);

            generateRedToken(B,P,T,redTokenList);
            // redTokenOutput.GenerateredToken(redTokenList.get(count));
        }


        else if (B.getVisited().size() == 1 && B.getIDConflict() != 0) {

            B.getVisited().clear();
            B.getShape().setCenterX(5000);
            B.getShape().setCenterY(5000);
        }
        // rule 2
        else if (isVisited== 1 && hasPreviousConflictWithPlace == 1 && hasPreviousConflictWithVC == 0) {

            B.getVisited().remove(T.getName());


        }
        // rule 3
        else if (isVisited == 1 && hasPreviousConflictWithPlace == 1 && hasPreviousConflictWithVC == 1) {

            B.getVisited().remove(T.getName());
            generateVCMatches(B, P, T);

                  /*  int count =B.getCount()+1;
                    redTokenList.get(count).setID(count);
                    redTokenList.get(count).setIDconflict(IDConflict);
                    redTokenList.get(count).setConflictPlace(conflictPlace);
                    redTokenList.get(count).setConflictPlacePredominance(T.getPlacePredominance());
                    redTokenList.get(count).getShape().setCenterX(615+count*10);
                    redTokenList.get(count).getShape().setCenterY(600+count*10);
                    redTokenList.get(count).getShape().setVisible(true);
                    redTokenList.get(count).setVcInfoList(vcInfo);
                    B.setCount(count);*/

        }

        // rule 4
        else if (isVisited == 1 && hasPreviousConflictWithPlace == 0 && hasPreviousConflictWithVC == 1) {

            B.getVisited().remove(T.getName());
            generateVCMatches(B, P, T);
                 /*   int count =B.getCount()+1;
                    redTokenList.get(count).setID(count);
                    redTokenList.get(count).setIDconflict(IDConflict);
                    redTokenList.get(count).setConflictPlace(conflictPlace);
                    redTokenList.get(count).setConflictPlacePredominance(T.getPlacePredominance());
                    redTokenList.get(count).getShape().setCenterX(615+count*10);
                    redTokenList.get(count).getShape().setCenterY(600+count*10);
                    redTokenList.get(count).getShape().setVisible(true);
                    redTokenList.get(count).setVcInfoList(vcInfo);
                    B.setCount(count);*/

        }

        // rule 5
        else if (isVisited== 1 && hasPreviousConflictWithPlace == 0
                && hasPreviousConflictWithVC(B, P) == 0 && hasPreviousConflictWithDependentVC(B, T) == 0) {

            B.getVisited().remove(T.getName());

        }

        // rule 6
        else if (isVisited == 0 && hasPreviousConflictWithVC == 0 && hasConflictWithVC == 0
                && hasConflictWithDependentVC(P, T) == 0) {

            B.getVisited().add(T.getName());
            generateVCChanges(B,P,T);

        }

        // rule 7
        else if (isVisited == 0 && hasPreviousConflictWithVC == 1 && hasConflictWithVC == 0) {

            B.getVisited().add(T.getName());
            int IDConflict = B.getIDConflict() + 1;
            generateVCMatches(B, P, T);

            generateVCChanges(B,P,T);
            B.setIDConflict(IDConflict);

            generateRedToken(B,P,T,redTokenList);

            // redTokenOutput.GenerateredToken(redTokenList.get(count));
        }


        // rule 8
        else if (isVisited == 0 && hasPreviousConflictWithVC == 0 && hasConflictWithVC == 1) {

            B.getVisited().add(T.getName());
            int IDConflict = B.getIDConflict() + 1;
            generateVCMatches(B, P, T);

            generateVCChanges(B,P,T);


            B.setIDConflict(IDConflict);

            generateRedToken(B,P,T,redTokenList);
            // redTokenOutput.GenerateredToken(redTokenList.get(count));

        }

        // rule 9
             /*   else if (isVisited == 0 && hasPreviousConflictWithVC == 1 && hasConflictWithVC == 1) {

                    System.out.println("rule9");
                    B.getVisited().add(T.getName());
                    int IDConflict = B.getIDConflict() + 1;
                    generateVCMatches(B, P, T);

                    generateVCChanges(B,P,T);


                    B.setIDConflict(IDConflict);

                    generateRedToken(B,P,T,redTokenList);
                    // redTokenOutput.GenerateredToken(redTokenList.get(count));
                }*/

        //}


        System.out.println();
        System.out.println();


    }








}
