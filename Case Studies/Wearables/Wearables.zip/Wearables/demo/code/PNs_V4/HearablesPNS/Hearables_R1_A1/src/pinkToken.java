import java.awt.*;

/**
 * Created by Sharmin on 12/24/2017.
 */
public class pinkToken {
    private int ID;
    private vcConditionImpact vcConditionImpact;
    private FilledCircle shape;

    public pinkToken(){}

    public pinkToken(int ID, vcConditionImpact vcConditionImpact, int centerX, int centerY, int radius, Color color)
    {
        this.ID =ID;
        this.vcConditionImpact =vcConditionImpact;
        this.shape = new FilledCircle(centerX, centerY, radius,color);
    }

    public int getID() {
        return ID;
    }

    public vcConditionImpact getVcConditionImpact() {
        return vcConditionImpact;
    }

    public FilledCircle getShape() {
        return shape;
    }
}
