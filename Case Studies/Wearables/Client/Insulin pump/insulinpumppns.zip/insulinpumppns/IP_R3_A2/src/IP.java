import javax.swing.*;
import java.awt.*;

/**
 * Created by Sharmin on 1/17/2018.
 */
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.util.List;
import java.util.Random;

public class IP extends JPanel
{


    public static void main(String [] args) {

        JFrame theGUI = new JFrame();
        theGUI.setTitle("Insulin Pump: R3-A2");
        theGUI.setSize(1600, 1000);
        theGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container pane = theGUI.getContentPane();

        IP_R3_A2_OnlyCalculation panel = new IP_R3_A2_OnlyCalculation(Color.white, 1600, 1000, 100, 150);
        //pane.add(panel);

        //theGUI.setVisible(true);
        while(true)
        {
            panel.Calculating();
        }
    }

}

