import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sharmin on 1/16/2018.
 */
public class IP_R3_A3 extends JPanel {
    public Place blue_Start;
    public Place blue_gCS;
    public Place blue_gNP;
    public Place blue_sP;
    public Place pink_Start;
    public Place pink_gCS;
    public Place pink_gNP;
    public Place end;

    public vcInfo vcInfo1, vcInfo2, vcInfo3, vcInfo4, vcInfo5, vcInfo6, vcInfo7, vcInfo8,vcInfo9;
    public vcInfo vcInfo10, vcInfo11, vcInfo12, vcInfo13, vcInfo14, vcInfo15, vcInfo16, vcInfo17,vcInfo18;
    public vcInfo vcInfo19, vcInfo20, vcInfo21;

    public pathDependency pd1,pd2,pd3,pd4,pd5,pd6,pd7;


    public Transition T1;
    public Transition T2;
    public Transition T3;

    public blueToken blueToken;
    public List<pinkToken> pinkToken_Start;
    public List<pinkToken> pinkToken_gCS;
    public List<pinkToken> pinkToken_gNP;

    private RightHeadedArrow A1, A2, A4, A5,A6, A8,A10,A12,A13,A15;
    private LeftHeadedArrow A3,A7,A14,A16;
    private DownHeadedArrow A9,A11;

    private Line L1, L2, L3, L4,L5,L6,L7,L8,L9,L10;

    private Simulation simulation=new Simulation();;

    public PinkTokenInput pinkTokenInput;

    public redToken rT1, rT2, rT3, rT4, rT5, rT6, rT7, rT8,rT9,rT10,rT11, rT12, rT13, rT14;
    public redToken rT15,rT16, rT17, rT18,rT19, rT20, rT21;

    public List<redToken> redTokenList;
    public  TransitionLogic TL = new TransitionLogic();
    public Output output=new Output();


    private Timer timer;

    private class MoveListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            redToken r;

            if(blueToken.getVisited().isEmpty() && blueToken.getIDConflict()!=0) {

                blueToken.getShape().setCenterX(5000);
                blueToken.getShape().setCenterY(5000);
                setVisible(false);
                System.out.println();
                System.out.println("Final State of  tokens:");
                TL.showBlueToken(blueToken);
                TL.showRedToken(redTokenList.get(blueToken.getCount()));
                System.out.println("--------------------------------------");
                System.out.println("Pink Token Value:");
                for (pinkToken P : pinkToken_gCS) {
                    String text = "(VC="+P.getVcConditionImpact().getVC()+", Condition= "+ P.getVcConditionImpact().getCondition()+", p-hat="+ P.getVcConditionImpact().getImpact()+")";
                    System.out.println(text);
                }
                System.exit(1);
            }
            else
            {
                simulation.simulatePN();
                repaint();

            }
            try {
                Thread.sleep(1000);
            }catch (InterruptedException ex) {
                ex.printStackTrace();
            }

        }
    }


    private class Simulation
    {
        public void simulatePN() {
            System.out.println();
            //    System.out.println("g"+T1.getActive()+"t"+T2.getActive());

            if (T1.getActive() == true &&  pinkToken_Start != null) {
                TL.applyRule(blueToken, pinkToken_Start, T1, redTokenList);
                TL.showBlueToken(blueToken);
                blueToken.getShape().setCenterX(440);
                blueToken.getShape().setCenterY(150);
                T1.setActive(false);
                T2.setActive(true);
            } else if (T2.getActive() == true && pinkToken_gCS != null) {
                TL.applyRule(blueToken, pinkToken_gCS, T2, redTokenList);
                TL.showBlueToken(blueToken);
                blueToken.getShape().setCenterX(780);
                blueToken.getShape().setCenterY(150);
                T2.setActive(false);
                T3.setActive(true);
            }
            else if (T3.getActive() == true && pinkToken_gNP != null) {
                TL.applyRule(blueToken, pinkToken_gNP, T3, redTokenList);
                TL.showBlueToken(blueToken);
                blueToken.getShape().setCenterX(1120);
                blueToken.getShape().setCenterY(150);
                T3.setActive(false);
                T1.setActive(true);
            }

        }

    }

    public   IP_R3_A3(Color backColor, int width, int height, int x, int y)
    {

        vcInfo1 = new vcInfo("Read", "Inhibit read", 0.2);
        vcInfo2 = new vcInfo("Read", "Read null data", 0.5);
        vcInfo3 = new vcInfo("Administer_insulin", "Set to false when instructed to administer", 0.2);
        vcInfo4 = new vcInfo("Administer_insulin", "Set to true when not told to administer", 0.5);
        vcInfo5 = new vcInfo("Administer_insulin", "Unable to set administer_insulin", 0.9);
        vcInfo6 = new vcInfo("bloodSugarLevel", "decrease i by more than 1 per state change", 0.5);

        vcInfo7 = new vcInfo("bloodSugarLevel", "Prevent processing", 0.2);
        vcInfo8 = new vcInfo("D", "Value of D raised", 0.2);
        vcInfo9 = new vcInfo("D", "Value of D lowered", 0.5);



        rT1 = new redToken(0, 0, vcInfo1, 0, "", 0, 1, x + 515, y + 5000, 25, Color.white);
        rT2 = new redToken(0, 0, vcInfo2, 0, "", 0, 1, x + 525, y + 5000, 25, Color.white);

        redTokenList = new ArrayList<redToken>();
        redTokenList.add(rT1);
        redTokenList.add(rT2);



        List<String> iPathDependency = new ArrayList<String>();
        pd1 = new pathDependency("i", iPathDependency);

        List<String> NPathDependency = new ArrayList<String>();
        pd2 = new pathDependency("N", NPathDependency);

        List<String> connectedPathDependency = new ArrayList<String>();
        pd3 = new pathDependency("connected", connectedPathDependency);

        List<String> sendPathDependency = new ArrayList<String>();
        pd4 = new pathDependency("send", sendPathDependency);


        setBackground(backColor);
        setPreferredSize(new Dimension(width, height));
        blue_Start = new Place("blueStart", "Blue", x, y, 75, Color.black);
        pink_Start = new Place("pinkStart", "Pink", x, y + 200, 75, Color.black);
        String[] T1InputList = {"blueStart", "pinkStart"};
        String[] T1OutputList = {"bluegCS", "end"};
        List<vcInfo> T1vcInfoList = new ArrayList<>();
        List<pathDependency> T1pathDependency = new ArrayList<>();


        T1vcInfoList.add(vcInfo1);
        T1vcInfoList.add(vcInfo2);
        T1vcInfoList.add(vcInfo3);
        T1vcInfoList.add(vcInfo4);
        T1vcInfoList.add(vcInfo5);
        T1vcInfoList.add(vcInfo6);
        T1vcInfoList.add(vcInfo7);
        T1vcInfoList.add(vcInfo8);
        T1vcInfoList.add(vcInfo9);

        T1 = new Transition("Initialize", T1InputList, T1OutputList, 0.5, T1vcInfoList, T1pathDependency, 0.75, x + 150, y - 75, 200, 40, Color.black);
        A1 = new RightHeadedArrow(x + 75, y, x + 150, y);
        L1 = new Line(x, y + 125, x, y + 100);
        A2 = new RightHeadedArrow(x, y + 100, x + 150, y + 100);
        L2 = new Line(x + 170, y + 200, x + 170, y + 125);
        A3 = new LeftHeadedArrow(x + 170, y + 200, x + 75, y + 200);
        A4 = new RightHeadedArrow(x + 190, y, x + 265, y);
        L5 = new Line(x + 180, y + 125, x + 180, y + 375);
        A10 = new RightHeadedArrow(x + 180, y + 375, x + 445, y + 375);

        blue_gCS = new Place("bluegCS", "Blue", x + 340, y, 75, Color.black);
        pink_gCS = new Place("pinkgCS", "Pink", x + 340, y + 200, 75, Color.black);
        String[] T2InputList = {"bluegCS", "pinkgCS"};
        String[] T2OutputList = {"bluegNP", "end"};
        List<vcInfo> T2vcInfoList = new ArrayList<>();
        List<pathDependency> T2pathDependency = new ArrayList<>();
        T2vcInfoList.add(vcInfo1);
        T2vcInfoList.add(vcInfo2);
        T2vcInfoList.add(vcInfo3);
        T2vcInfoList.add(vcInfo4);
        T2vcInfoList.add(vcInfo5);
        T2vcInfoList.add(vcInfo6);
        T2vcInfoList.add(vcInfo7);
        T2vcInfoList.add(vcInfo8);
        T2vcInfoList.add(vcInfo9);


        T2 = new Transition("Adjust", T2InputList, T2OutputList, 0.5, T2vcInfoList, T2pathDependency, 0.75, x + 490, y - 75, 200, 40, Color.black);
        A5 = new RightHeadedArrow(x + 415, y, x + 490, y);
        L3 = new Line(x + 335, y + 100, x + 335, y + 125);

        A6 = new RightHeadedArrow(x + 335, y + 100, x + 490, y + 100);
        L4 = new Line(x + 500, y + 125, x + 500, y + 200);

        A7 = new LeftHeadedArrow(x + 500, y + 200, x + 415, y + 200);
        A8 = new RightHeadedArrow(x + 530, y, x + 605, y);
        A9 = new DownHeadedArrow(x + 510, y + 125, x + 510, y + 275);

        blue_gNP = new Place("bluegNP","Blue",x+680, y, 75, Color.black);
        pink_gNP = new Place("pinkgNP","Pink",x+680, y+200, 75, Color.black);
        String [] T3InputList= {"bluegNP","pinkgNP"};
        String [] T3OutputList= {"bluesP","end"};
        List<vcInfo> T3vcInfoList = new ArrayList<>();
        List<pathDependency> T3pathDependency =new ArrayList<>();
        T3vcInfoList.add(vcInfo1);
        T3vcInfoList.add(vcInfo2);
        T3vcInfoList.add(vcInfo3);
        T3vcInfoList.add(vcInfo4);
        T3vcInfoList.add(vcInfo5);
        T3vcInfoList.add(vcInfo6);
        T3vcInfoList.add(vcInfo7);
        T3vcInfoList.add(vcInfo8);
        T3vcInfoList.add(vcInfo9);


        T3 =new Transition("Administer",T3InputList, T3OutputList , 0.9,T3vcInfoList, T3pathDependency,0.75,x+830, y-75, 200,40, Color.black);
        A12 = new RightHeadedArrow(x+755,y,x+830,y);
        L8 = new Line(x+675, y+100, x+675, y+125 );
        A13 = new RightHeadedArrow(x+675, y+100, x+830, y+100);
        L9 = new Line(x+845, y+125, x+845, y+200 );
        A14 = new LeftHeadedArrow(x+845, y+200, x+755, y+200);
        A15 = new RightHeadedArrow(x+870,y,x+945,y);

        blue_sP = new Place("bluesP","Blue",x+1020, y, 75, Color.black);

        //L6 = new Line(x + 675, y - 75, x + 675, y - 130);
        //L7 = new Line(x + 675, y - 130, x + 160, y - 130);
        A11 = new DownHeadedArrow(x + 160, y - 130, x + 160, y - 75);
        L6 = new Line(x + 1020, y - 75, x + 1020, y - 130);
        L7 = new Line(x + 1020, y - 130, x + 160, y - 130);
        L10 = new Line(x + 855, y + 125, x + 855, y + 350);
        A16 = new LeftHeadedArrow(x + 855, y + 350, x + 590, y + 350);



        List<vcMatches> vcMatchesList = new ArrayList<>();
        List<vcChanges> vcChangesList = new ArrayList<>();
        List<String> visited = new ArrayList<>();
        blueToken = new blueToken(visited, vcMatchesList, vcChangesList, 0, 0, x, y, 25, Color.blue);
        blueToken.getShape().setDirection(180);
        blueToken.getShape().setVelocity(300);
        timer = new Timer(1000, new MoveListener());
        timer.start();

        pinkTokenInput = new PinkTokenInput();
        pinkToken_Start = pinkTokenInput.startPink(x, y, "R3-A3.txt");
        pinkToken_gCS = pinkTokenInput.gCSPink(x, y, "R3-A3.txt");
        pinkToken_gNP = pinkTokenInput.gNPPink(x, y, "R3-A3.txt");


        end = new Place("end", "Red", x + 515, y + 350, 75, Color.black);
        T1.setActive(true);


    }


    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        blue_Start.getShape().draw(g);
        blue_gCS.getShape().draw(g);
        blue_gNP.getShape().draw(g);
        blue_sP.getShape().draw(g);


        pink_Start.getShape().draw(g);
        pink_gCS.getShape().draw(g);
        pink_gNP.getShape().draw(g);

        T1.getShape().draw(g);
        T2.getShape().draw(g);
        T3.getShape().draw(g);


        A1.draw(g);
        A2.draw(g);
        A3.draw(g);
        A4.draw(g);

        A5.draw(g);
        A6.draw(g);
        A7.draw(g);
        A8.draw(g);
        A9.draw(g);
        A10.draw(g);
        A11.draw(g);
        A12.draw(g);
        A13.draw(g);
        A14.draw(g);
        A15.draw(g);
        A16.draw(g);


        L1.draw(g);
        L2.draw(g);
        L3.draw(g);
        L4.draw(g);
        L5.draw(g);
        L6.draw(g);
        L7.draw(g);
        L8.draw(g);
        L9.draw(g);
        L10.draw(g);
        g.setFont(new Font("Arial", Font.BOLD, 25));
        g.drawString("I",265,95);
        g.drawString("n",260,115);
        g.drawString("i",265,135);
        g.drawString("t",265,155);
        g.drawString("i",265,175);
        g.drawString("a",262,195);
        g.drawString("l",265,215);
        g.drawString("i",265,235);
        g.drawString("z",262,255);
        g.drawString("e",260,275);

        g.drawString("A",605,125);
        g.drawString("d",605,145);
        g.drawString("j",610,165);
        g.drawString("u",605,185);
        g.drawString("s",605,205);
        g.drawString("t",607,225);

        g.drawString("A",945,95);
        g.drawString("d",945,115);
        g.drawString("m",945,135);
        g.drawString("i",950,155);
        g.drawString("n",945,175);
        g.drawString("i",950,195);
        g.drawString("s",947,215);
        g.drawString("t",950,235);
        g.drawString("e",947,255);
        g.drawString("r",947,275);



        g.drawString("Start",45,242);
        g.drawString("Initialize",385,242);
        g.drawString("Adjust",745,242);
        g.drawString("Administer",1080,242);
        g.drawString("Pink_Initialize",45,450);
        g.drawString("Pink_Adjust",385,450);
        g.drawString("Pink_Administer",725,450);
        g.drawString("End",600,600);



        blueToken.getShape().draw(g);

        for (pinkToken P : pinkToken_Start) {
            P.getShape().draw(g);
        }

        for (pinkToken P : pinkToken_gCS) {
            P.getShape().draw(g);
            String text = "(VC="+P.getVcConditionImpact().getVC()+", Condition= "+ P.getVcConditionImpact().getCondition()+", p-hat="+ P.getVcConditionImpact().getImpact()+")";
            g.drawString("A",430,350);
            g.setFont(new Font("Arial", Font.BOLD, 15));
            g.drawString(text,300,400);
        }

        for (pinkToken P : pinkToken_gNP) {
            P.getShape().draw(g);
        }
        end.getShape().draw(g);
        rT1.getShape().draw(g);
        rT2.getShape().draw(g);

    }



}

