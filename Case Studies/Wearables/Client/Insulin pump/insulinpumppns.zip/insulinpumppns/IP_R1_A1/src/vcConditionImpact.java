/**
 * Created by Sharmin on 12/24/2017.
 */
public class vcConditionImpact {
    private String VC;
    private String condition;
    private double impact;

    public vcConditionImpact(){};

    public vcConditionImpact(String VC, String condition, double impact)
    {
        this.VC =VC;
        this.condition =condition;
        this.impact =impact;
    }

    public String getVC() {
        return VC;
    }

    public String getCondition() {
        return condition;
    }

    public double getImpact() {
        return impact;
    }
}
