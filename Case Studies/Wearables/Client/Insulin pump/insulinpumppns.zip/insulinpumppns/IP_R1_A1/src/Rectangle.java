import java.awt.*;

/**
 * Created by Sharmin on 12/19/2017.
 */
public class Rectangle {
    private int X, Y, height, width;
    private Color color;
    private boolean filled;

    public Rectangle(int x, int y, int height, int width, Color c)
    {
        this.X = x;
        this.Y = y;
        this.height = height;
        this.width=width;
        this.color = c;
        this.filled = false;
    }

    public void draw(Graphics g)
    {
        Color oldColor = g.getColor();
        g.setColor(color);
        g.drawRect(X,Y,width,height);
        g.setColor(oldColor);
    }

    public void fill(Graphics g)
    {
        Color oldColor = g.getColor();
        g.setColor(color);
        g.fillRect(X,Y,width,height);
        g.setColor(oldColor);
    }

    public int getX()
    {
        return X;
    }

    public int getY()
    {
        return Y;
    }

    public int getHeight()
    {
        return height;
    }

    public int getWidth()
    {
        return width;
    }

}
