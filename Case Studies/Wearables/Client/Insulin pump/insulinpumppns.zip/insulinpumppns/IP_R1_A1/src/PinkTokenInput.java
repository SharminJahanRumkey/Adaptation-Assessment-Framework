import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.List;

class PinkTokenInput {

    String inputValue="";
    public PinkTokenInput (){



    }

    public List<pinkToken> startPink(int x, int y, String fileName)
    {
        String csvFile = "./"+fileName;
        String line = "";
        String changes = ";";
        List<pinkToken> pinkToken_Start=new ArrayList<pinkToken>();


        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] inputVals = line.split(changes);

                if(inputVals[0].equals("Initialize"))
                {
                    pinkToken pink;
                    vcConditionImpact vcConditionImpact= new vcConditionImpact(inputVals[1], inputVals[2],Double.parseDouble( inputVals[3]));
                    pink =new pinkToken(1,vcConditionImpact, x, y+200, 25, Color.magenta);
                    pinkToken_Start.add(pink);

                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return pinkToken_Start;
    }

    public  List<pinkToken> gCSPink(int x, int y, String fileName)
    {
        String csvFile = "./"+fileName;
        String line = "";
        String changes = ";";
        List<pinkToken> pinkToken_gCS=new ArrayList<pinkToken>();


        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] inputVals = line.split(changes);
                if(inputVals[0].equals("Adjust"))
                {
                    pinkToken pink;
                    vcConditionImpact vcConditionImpact= new vcConditionImpact(inputVals[1], inputVals[2],Double.parseDouble( inputVals[3]));
                    pink = new pinkToken(1,vcConditionImpact,x+340, y+200, 25, Color.magenta);
                    pinkToken_gCS.add(pink);


                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return pinkToken_gCS;
    }

    public  List<pinkToken> gNPPink(int x, int y, String fileName)
    {
        String csvFile = "./"+fileName;
        String line = "";
        String changes = ";";
        List<pinkToken> pinkToken_gCS=new ArrayList<pinkToken>();


        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] inputVals = line.split(changes);
                if(inputVals[0].equals("Play"))
                {
                    pinkToken pink;
                    vcConditionImpact vcConditionImpact= new vcConditionImpact(inputVals[1], inputVals[2],Double.parseDouble( inputVals[3]));
                    pink = new pinkToken(1,vcConditionImpact,x+680, y+200, 25, Color.magenta);
                    pinkToken_gCS.add(pink);


                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return pinkToken_gCS;
    }
/*
    public pinkToken gNPPink(int x, int y)
    {
        String csvFile = "./input.txt";
        String line = "";
        String changes = ";";
        pinkToken pinkToken_gNP=null;


        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] inputVals = line.split(changes);
                if(inputVals[0].equals("gNP"))
                {
                    vcConditionImpact vcConditionImpact= new vcConditionImpact(inputVals[1], inputVals[2],Double.parseDouble( inputVals[3]));
                    pinkToken_gNP =new pinkToken(1,vcConditionImpact,x+680, y+300, 5, Color.magenta);


                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return pinkToken_gNP;
    }

    public pinkToken sPPink(int x, int y)
    {
        String csvFile = "./input.txt";
        String line = "";
        String changes = ";";
        pinkToken pinkToken_sP=null;


        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] inputVals = line.split(changes);
                if(inputVals[0].equals("sP"))
                {
                    vcConditionImpact vcConditionImpact= new vcConditionImpact(inputVals[1], inputVals[2],Double.parseDouble( inputVals[3]));
                    pinkToken_sP =new pinkToken(1,vcConditionImpact,x+1020, y+300, 5, Color.magenta);


                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return pinkToken_sP;
    }
*/
    public String getInput()
    {
        return this.inputValue;
    }

}
