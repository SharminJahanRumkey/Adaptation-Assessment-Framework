import com.sun.org.apache.xerces.internal.xs.StringList;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sharmin on 12/24/2017.
 */
public class blueToken {

    private List<String> visited = new ArrayList<String>();
    private List<vcMatches> vcMatchesList=new ArrayList<vcMatches>();
    private List<vcChanges> vcChangesList = new ArrayList<vcChanges>();
    private int IDConflict;
    private int count;
    private FilledCircle shape;

    public blueToken(List<String> visited, List<vcMatches> vcMatchesList, List<vcChanges> vcChangesList,int IDConflict,int count
                    ,int centerX, int centerY, int radius, Color color)
    {
        this.visited =visited;
        this.vcMatchesList = vcMatchesList;
        this.vcChangesList = vcChangesList;
        this.IDConflict = IDConflict;
        this.count = count;
        this.shape = new FilledCircle(centerX,centerY,radius,color);
    }

    public int getIDConflict() {
        return IDConflict;
    }

    public int getCount() {
        return count;
    }

    public List<vcChanges> getVcChangesList() {
        return vcChangesList;
    }

    public List<vcMatches> getVcMatchesList() {
        return vcMatchesList;
    }

    public List<String> getVisited() {
        return visited;
    }

    public FilledCircle getShape() {
        return shape;
    }

    public void setIDConflict(int IDConflict)
    {
        this.IDConflict=IDConflict;
    }

    public void setCount(int count)
    {
        this.count=count;
    }


}
