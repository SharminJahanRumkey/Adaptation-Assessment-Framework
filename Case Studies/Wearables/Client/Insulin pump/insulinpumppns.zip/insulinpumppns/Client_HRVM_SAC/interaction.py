#!/bin/python

import Queue
import requests
import sys
import threading
import time




def get_sac_mode_utility_weights():
    return [1,3,2,4]


def get_fac_mode_utility_weights():
    return [2,4,3,1]

def read_contents_of_file(file_name):
    f = open(file_name, "r")
    contents = ""
    if f.mode == "r":
        contents = f.read().strip()
    f.close()
    return contents


initiator = threading.Lock()
chan = Queue.Queue(maxsize=1)

WAIT_TIME = 0.5
ANNOUNCE = 0
AGREE = 1
DISAGREE = 2
MODIFY = 3
CONFIRM = 4
WITHDRAW = 5

def post(plan, mtype, tag):
    global chan

    chan.put((plan, mtype, tag))
    return


def clear_channel():
    global chan

    while not chan.empty():
        chan.get()
    return


def interaction_protocol(results, tag):
    global chan
    global WAIT_TIME
    global ANNOUNCE
    global AGREE
    global DISAGREE
    global MODIFY
    global CONFIRM
    global WITHDRAW

    plans = results[:]

    while plans:
        isInitiator = initiator.acquire(False)
        if isInitiator:
            print str(tag) + " => Initiating Interaction Protocol"
            if not plans:
                clear_channel()
                print str(tag) + " => No plans remaining : Sending WITHDRAW"
                post(None, WITHDRAW, tag)
                initiator.release()
                time.sleep(WAIT_TIME)
                return None
            plan = plans[0]
            clear_channel()
            print str(tag) + " => Announcing plan = '" + str(plan) + "' : Sending ANNOUNCE"
            post(plan, ANNOUNCE, tag)
            time.sleep(WAIT_TIME)
            while True:
                if chan.empty():
                    initiator.release()
                    break
                plan, response, sender = chan.get()
                if sender == tag:
                    initiator.release()
                    break
                if response == AGREE:
                    print str(tag) + " => Received response 'AGREE' from '" + str(sender) + "' : Sending CONFIRM"
                    post(plan, CONFIRM, tag)
                    initiator.release()
                    return plan
                if response == DISAGREE:
                    print str(tag) + " => Received response 'DISAGREE' from '" + str(sender) + "'"
                    plans.pop(0)
                    initiator.release()
                    break
                if response == MODIFY:
                    print str(tag) + " => Received response 'MODIFY' from '" + str(sender) + "' with plan '" + str(plan) + "'"
                    plans.pop(0)
                    if not (plan in results):
                        print str(tag) + " => Does not recognize plan '" + str(plan) + "' : Sending DISAGREE"
                        post(plan, DISAGREE, tag)
                        initiator.release()
                        time.sleep(WAIT_TIME)
                        break
                    if results.index(plan) <= (len(results) / 2):
                        print str(tag) + " => Confirming plan '" + str(plan) + "' : Sending CONFIRM"
                        post(plan, CONFIRM, tag)
                        initiator.release()
                        return plan
                    if not plans:
                        clear_channel()
                        print str(tag) + " => No plans remaining : Sending WITHDRAW"
                        post(None, WITHDRAW, tag)
                        initiator.release()
                        time.sleep(WAIT_TIME)
                        return None
                    print str(tag) + " => Modifying plan '" + str(plan) + "' -> '" + str(plans[0]) + "' : Sending MODIFY"
                    plan = plans[0]
                    post(plan, MODIFY, tag)
                    time.sleep(WAIT_TIME)
                    continue
                initiator.release()
                break
            continue
        else:
            print str(tag) + " => Participating in Interaction Protocol"
            while True:
                if chan.empty():
                    time.sleep(WAIT_TIME)
                    if chan.empty():
                        break
                plan, response, sender = chan.get()
                if sender == tag:
                    break
                print str(tag) + " => Received '" + str(plan) + "' from '" + str(sender) + "'"
                if response == ANNOUNCE:
                    if not (plan in results):
                        print str(tag) + " => Does not recognize plan '" + str(plan) + "' : Sending DISAGREE"
                        post(plan, DISAGREE, tag)
                        time.sleep(WAIT_TIME)
                        break
                    if results.index(plan) <= (len(results) / 2):
                        print str(tag) + " => Agrees to plan '" + str(plan) + "' : Sending AGREE"
                        post(plan, AGREE, tag)
                        time.sleep(WAIT_TIME)
                        continue
                    if not plans:
                        print str(tag) + " => No plans remaining : Sending DISAGREE"
                        post(plan, DISAGREE, tag)
                        time.sleep(WAIT_TIME)
                        continue
                    print str(tag) + " => Modifying plan '" + str(plan) + "' -> '" + str(plans[0]) + "' : Sending MODIFY"
                    plan = plans[0]
                    post(plan, MODIFY, tag)
                    time.sleep(WAIT_TIME)
                    continue
                if response == DISAGREE:
                    print str(tag) + " => Received 'DISAGREE' from '" + str(tag) + "'"
                    plans.pop(0)
                    break
                if response == MODIFY:
                    print str(tag) + " => Received 'MODIFY' from '" + str(tag) + "'"
                    if not (plan in results):
                        print str(tag) + " => Does not recognize plan '" + str(plan) + "' : Sending DISAGREE"
                        post(plan, DISAGREE, tag)
                        time.sleep(WAIT_TIME)
                        break
                    if results.index(plan) <= len(results) / 2:
                        print str(tag) + " => Agrees to plan '" + str(plan) + "' : Sending AGREE"
                        post(plan, AGREE, tag)
                        time.sleep(WAIT_TIME)
                        continue
                    if not plans:
                        print str(tag) + " => No plans remaining : Sending DISAGREE"
                        post(plan, DISAGREE, tag)
                        time.sleep(WAIT_TIME)
                        continue
                    print str(tag) + " => Modifying plan '" + str(plan) + "' -> '" + str(plans[0]) + "' : Sending MODIFY"
                    plan = plans[0]
                    post(plan, MODIFY, tag)
                    time.sleep(WAIT_TIME)
                    continue
                if response == CONFIRM:
                    print str(tag) + " => Received 'CONFIRM' from '" + str(sender) + "'"
                    return plan
                if response == WITHDRAW:
                    print str(tag) + " => Received 'WITHDRAW' from '" + str(sender) + "'"
                    break
                break
            continue
        continue
    return None


if __name__ == "__main__":
    print("I am")
    sac_rankings = get_sac_mode_utility_weights()
    fac_rankings = get_fac_mode_utility_weights()
	

    t1 = threading.Thread(target=interaction_protocol, args=(fac_rankings, "FAC"))
    t2 = threading.Thread(target=interaction_protocol, args=(sac_rankings, "SAC"))

    t1.start()
    t2.start()

