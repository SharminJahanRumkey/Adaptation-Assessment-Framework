import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sharmin on 12/24/2017.
 */
public class vcMatches {
    private int IDConflict;
    private List<vcInfo> vcInfoList = new ArrayList<vcInfo>();
    private String conflictPlace;
    private double impact;

    public vcMatches(){}

    public vcMatches( int IDConflict, List<vcInfo> vcInfoList, String conflictPlace,double impact)
    {
        this.IDConflict = IDConflict;
        this.vcInfoList = vcInfoList;
        this.conflictPlace = conflictPlace;
        this.impact =impact;
    }

    public int getIDConflict() {
        return IDConflict;
    }

    public List<vcInfo> getVcInfoList() {
        return vcInfoList;
    }

    public String getConflictPlace() {
        return conflictPlace;
    }

    public double getImpact() {
        return impact;
    }
}
