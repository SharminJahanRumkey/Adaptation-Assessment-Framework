import javax.swing.*;
import java.awt.*;

/**
 * Created by Sharmin on 1/17/2018.
 */
import java.awt.*;
        import java.awt.event.*;
        import java.util.*;
        import java.io.*;
        import javax.swing.*;
        import java.util.List;
        import java.util.Random;

public class Hearables extends JPanel
{


    public static void main(String [] args) {

        JFrame theGUI = new JFrame();
        theGUI.setTitle("Hearables: R1-A1");
        theGUI.setSize(2500, 1000);
        theGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container pane = theGUI.getContentPane();

        Hearables_R1_A1 panel = new Hearables_R1_A1(Color.white, 2500, 1000, 100, 150);
        pane.add(panel);

        theGUI.setVisible(true);
    }

}

