import java.awt.*;

/**
 * Created by Sharmin on 12/24/2017.
 */
public class Place {
    private String name;
    private String type;
    private Circle shape;

    public Place(String name, String type, int centerX, int centerY, int radius, Color color){
        this.name = name;
        this.type = type;
        this.shape = new Circle(centerX,centerY,radius,color);
    }

    public String getName(){ return this.name;}

    public String getType(){ return this.type;}

    public Circle getShape() {return this.shape;}
}
