import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

class Output {

    public File file1;
    public File file2;


    public Output()
    {
        try {

            file1 = new File("./blueToken_R3_A3.txt");
            file2 = new File("./redToken_R3_A3.txt");

            if (!file1.exists()) {
                file1.createNewFile();
            }
            else {
                file1.delete();
                file1.createNewFile();
            }

            if (!file2.exists()) {
                file2.createNewFile();
            }
            else {
                file2.delete();
                file2.createNewFile();
            }

        }catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void GenerateblueToken(String value,String Type)
    {
        try{

            FileWriter fw=new FileWriter(file1.getAbsoluteFile(), true);

            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(value);
            bw.newLine();
            bw.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void GenerateredToken(String value, String Type)
    {
        try{


            FileWriter fw=new FileWriter(file2.getAbsoluteFile(), true);

            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(value);
            bw.newLine();
            bw.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
