/**
 * Created by Sharmin on 12/24/2017.
 */
public class vcInfo {
    private String VC;
    private String condition;
    private double vcImpact;

    public vcInfo(String VC, String condition, double vcImpact)
    {
        this.VC = VC;
        this.condition = condition;
        this.vcImpact = vcImpact;
    }

    public String getVC(){ return this.VC;}

    public String getCondition() {return this.condition;}

    public double getVcImpact() { return this.vcImpact; }
}
