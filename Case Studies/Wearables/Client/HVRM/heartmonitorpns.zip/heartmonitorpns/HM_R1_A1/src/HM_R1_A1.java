import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sharmin on 1/16/2018.
 */
public class HM_R1_A1 extends JPanel {
    public Place blue_Start;
    public Place blue_gCS;
    public Place blue_gNP;
    public Place pink_Start;
    public Place pink_gCS;
    public Place end;
    public int myflag =0;

    public vcInfo vcInfo1, vcInfo2, vcInfo3, vcInfo4, vcInfo5, vcInfo6, vcInfo7, vcInfo8,vcInfo9;
    public vcInfo vcInfo10, vcInfo11, vcInfo12, vcInfo13, vcInfo14, vcInfo15, vcInfo16, vcInfo17,vcInfo18;
    public vcInfo vcInfo19, vcInfo20, vcInfo21;

    public pathDependency pd1,pd2,pd3,pd4,pd5,pd6,pd7;


    public Transition T1,T1_temp;
    public Transition T2;

    public blueToken blueToken;
    public List<pinkToken> pinkToken_Start;
    public List<pinkToken> pinkToken_gCS;

    private RightHeadedArrow A1, A2, A4, A5,A6, A8,A10;
    private LeftHeadedArrow A3,A7;
    private DownHeadedArrow A9,A11;

    private Line L1, L2, L3, L4,L5,L6,L7;

    private Simulation simulation=new Simulation();;

    public PinkTokenInput pinkTokenInput;

    public redToken rT1, rT2, rT3, rT4, rT5, rT6, rT7, rT8,rT9,rT10,rT11, rT12, rT13, rT14;
    public redToken rT15,rT16, rT17, rT18,rT19, rT20, rT21;

    public List<redToken> redTokenList;
    public  TransitionLogic TL = new TransitionLogic();
    public Output output=new Output();


    private Timer timer;

    private class MoveListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            redToken r;

            if(blueToken.getVisited().isEmpty() && blueToken.getIDConflict()!=0) {

                blueToken.getShape().setCenterX(5000);
                blueToken.getShape().setCenterY(5000);
                setVisible(false);
                System.out.println();
                System.out.println("Final State of  tokens:");
                System.out.println("Blue token value:");
                System.out.println(TL.showBlueToken(blueToken));
                System.out.println("--------------------------------------------");
                System.out.println("Red token value:");
                System.out.print(TL.showRedToken(redTokenList.get(blueToken.getCount())));
                System.out.println("--------------------------------------");
                System.out.println("Pink Token Value:");

                for (pinkToken P : pinkToken_gCS) {
                    String text = "(VC="+P.getVcConditionImpact().getVC()+", Condition= "+ P.getVcConditionImpact().getCondition()+", p-hat="+ P.getVcConditionImpact().getImpact()+")";
                    System.out.println(text);
                }
                System.exit(1);
            }
            else
            {
                simulation.simulatePN();
                repaint();

            }
            try {
                Thread.sleep(1000);
            }catch (InterruptedException ex) {
                ex.printStackTrace();
            }

        }
    }


    private class Simulation
    {
        public void simulatePN() {
            System.out.println();
            //    System.out.println("g"+T1.getActive()+"t"+T2.getActive());

            if (T1.getActive() == true &&  pinkToken_Start != null) {
                TL.applyRule(blueToken, pinkToken_Start, T1, redTokenList);
                System.out.println("Blue token value:");
                System.out.println(TL.showBlueToken(blueToken));
                System.out.println("--------------------------------------------");
                myflag = 1;
                blueToken.getShape().setCenterX(440);
                blueToken.getShape().setCenterY(150);
                T1.setActive(false);
                T2.setActive(true);
            } else if (T2.getActive() == true && pinkToken_gCS != null) {
                TL.applyRule(blueToken, pinkToken_gCS, T2, redTokenList);
                System.out.println("Blue token value:");
                System.out.println(TL.showBlueToken(blueToken));
                System.out.println("--------------------------------------------");
                blueToken.getShape().setCenterX(780);
                blueToken.getShape().setCenterY(150);
                T2.setActive(false);
                T1.setActive(true);
                myflag = 2;
            }

        }

    }

    public   HM_R1_A1(Color backColor, int width, int height, int x, int y)
    {

        vcInfo1 = new vcInfo("i", "Remove i := 0, set i > N, increase i by more than 1 per state change, set i to 0 where it is not currently performed", 0.2);
        vcInfo2 = new vcInfo("i", "Set i < 0, decrease i by more than 1 per state change", 0.5);

        vcInfo4 = new vcInfo("N", "Reduce N, reset N to L where is it not currently performed", 0.2);
        vcInfo5 = new vcInfo("N", "Increase N above L", 0.5);
        vcInfo6 = new vcInfo("N", "Increase N where is it not currently performed", 0.9);

        vcInfo7 = new vcInfo("connected", "Inhibit connection", 0.2);
        vcInfo8 = new vcInfo("connected", "Disconnect without altering N", 0.5);

        vcInfo10 = new vcInfo("send", "Inhibit send while connected", 0.2);
        vcInfo11 = new vcInfo("send", "Expect send while disconnected", 0.5);
        vcInfo12 = new vcInfo("send", "Sending null data (empty packets)", 0.9);


        rT1 = new redToken(0, 0, vcInfo1, 0, "", 0, 0.75, x + 515, y + 5000, 25, Color.white);
        rT2 = new redToken(0, 0, vcInfo2, 0, "", 0, 0.75, x + 525, y + 5000, 25, Color.white);

        redTokenList = new ArrayList<redToken>();
        redTokenList.add(rT1);
        redTokenList.add(rT2);



        List<String> iPathDependency = new ArrayList<String>();
        pd1 = new pathDependency("i", iPathDependency);

        List<String> NPathDependency = new ArrayList<String>();
        pd2 = new pathDependency("N", NPathDependency);

        List<String> connectedPathDependency = new ArrayList<String>();
        pd3 = new pathDependency("connected", connectedPathDependency);

        List<String> sendPathDependency = new ArrayList<String>();
        pd4 = new pathDependency("send", sendPathDependency);


        setBackground(backColor);
        setPreferredSize(new Dimension(width, height));
        blue_Start = new Place("blueStart", "Blue", x, y, 75, Color.black);
        pink_Start = new Place("pinkStart", "Pink", x, y + 200, 75, Color.black);
        String[] T1InputList = {"blueStart", "pinkStart"};
        String[] T1OutputList = {"bluegCS", "end"};
        List<vcInfo> T1vcInfoList = new ArrayList<>();
        List<pathDependency> T1pathDependency = new ArrayList<>();

        T1vcInfoList.add(vcInfo1);
        T1vcInfoList.add(vcInfo2);
        T1vcInfoList.add(vcInfo4);
        T1vcInfoList.add(vcInfo5);
        T1vcInfoList.add(vcInfo6);
        T1vcInfoList.add(vcInfo7);
        T1vcInfoList.add(vcInfo8);
        T1pathDependency.add(pd1);
        T1pathDependency.add(pd2);
        T1pathDependency.add(pd3);
        T1 = new Transition("Initialize", T1InputList, T1OutputList, 0.5, T1vcInfoList, T1pathDependency, 0.75, x + 150, y - 75, 200, 40, Color.black);
        A1 = new RightHeadedArrow(x + 75, y, x + 150, y);
        L1 = new Line(x, y + 125, x, y + 100);
        A2 = new RightHeadedArrow(x, y + 100, x + 150, y + 100);
        L2 = new Line(x + 170, y + 200, x + 170, y + 125);
        A3 = new LeftHeadedArrow(x + 170, y + 200, x + 75, y + 200);
        A4 = new RightHeadedArrow(x + 190, y, x + 265, y);
        L5 = new Line(x + 180, y + 125, x + 180, y + 375);
        A10 = new RightHeadedArrow(x + 180, y + 375, x + 445, y + 375);

        blue_gCS = new Place("bluegCS", "Blue", x + 340, y, 75, Color.black);
        pink_gCS = new Place("pinkgCS", "Pink", x + 340, y + 200, 75, Color.black);
        String[] T2InputList = {"bluegCS", "pinkgCS"};
        String[] T2OutputList = {"bluegNP", "end"};
        List<vcInfo> T2vcInfoList = new ArrayList<>();
        List<pathDependency> T2pathDependency = new ArrayList<>();
        T2vcInfoList.add(vcInfo1);
        T2vcInfoList.add(vcInfo2);
        T2vcInfoList.add(vcInfo4);
        T2vcInfoList.add(vcInfo5);
        T2vcInfoList.add(vcInfo6);
        T2vcInfoList.add(vcInfo7);
        T2vcInfoList.add(vcInfo8);
        T2vcInfoList.add(vcInfo10);
        T2vcInfoList.add(vcInfo11);
        T2vcInfoList.add(vcInfo12);
        T2pathDependency.add(pd1);
        T2pathDependency.add(pd2);
        T2pathDependency.add(pd3);
        T2pathDependency.add(pd4);
        T2 = new Transition("Adjust", T2InputList, T2OutputList, 0.5, T2vcInfoList, T2pathDependency, 0.75, x + 490, y - 75, 200, 40, Color.black);
        A5 = new RightHeadedArrow(x + 415, y, x + 490, y);
        L3 = new Line(x + 335, y + 100, x + 335, y + 125);

        A6 = new RightHeadedArrow(x + 335, y + 100, x + 490, y + 100);
        L4 = new Line(x + 500, y + 125, x + 500, y + 200);

        A7 = new LeftHeadedArrow(x + 500, y + 200, x + 415, y + 200);
        A8 = new RightHeadedArrow(x + 530, y, x + 605, y);
        A9 = new DownHeadedArrow(x + 510, y + 125, x + 510, y + 275);


        blue_gNP = new Place("bluegNP", "Blue", x + 680, y, 75, Color.black);

        L6 = new Line(x + 675, y - 75, x + 675, y - 130);
        L7 = new Line(x + 675, y - 130, x + 160, y - 130);
        A11 = new DownHeadedArrow(x + 160, y - 130, x + 160, y - 75);


        List<vcMatches> vcMatchesList = new ArrayList<>();
        List<vcChanges> vcChangesList = new ArrayList<>();
        List<String> visited = new ArrayList<>();
        blueToken = new blueToken(visited, vcMatchesList, vcChangesList, 0, 0, x, y, 25, Color.blue);
        blueToken.getShape().setDirection(180);
        blueToken.getShape().setVelocity(300);
        timer = new Timer(1000, new MoveListener());
        timer.start();

        pinkTokenInput = new PinkTokenInput();
        pinkToken_Start = pinkTokenInput.startPink(x, y, "R1-A1.txt");
        pinkToken_gCS = pinkTokenInput.gCSPink(x, y, "R1-A1.txt");


        end = new Place("end", "Red", x + 515, y + 350, 75, Color.black);
        T1.setActive(true);

    }


    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        blue_Start.getShape().draw(g);
        blue_gCS.getShape().draw(g);
        blue_gNP.getShape().draw(g);



        pink_Start.getShape().draw(g);
        pink_gCS.getShape().draw(g);

        T1.getShape().draw(g);
        T2.getShape().draw(g);


        A1.draw(g);
        A2.draw(g);
        A3.draw(g);
        A4.draw(g);

        A5.draw(g);
        A6.draw(g);
        A7.draw(g);
        A8.draw(g);
        A9.draw(g);
        A10.draw(g);
        A11.draw(g);


        L1.draw(g);
        L2.draw(g);
        L3.draw(g);
        L4.draw(g);
        L5.draw(g);
        L6.draw(g);
        L7.draw(g);
        g.setFont(new Font("Arial", Font.BOLD, 25));
        g.setColor(Color.blue);
        g.drawString("Requirement: Buffer does not overflow  ",315,625);
        g.drawString("Adaptation: Stay connected, Send empty packets,  Fostering is not allowed",155,655);
        g.setColor(Color.black);
        g.drawString("I",265,95);
        g.drawString("n",260,115);
        g.drawString("i",265,135);
        g.drawString("t",265,155);
        g.drawString("i",265,175);
        g.drawString("a",262,195);
        g.drawString("l",265,215);
        g.drawString("i",265,235);
        g.drawString("z",262,255);
        g.drawString("e",260,275);

        g.drawString("A",605,125);
        g.drawString("d",605,145);
        g.drawString("j",610,165);
        g.drawString("u",605,185);
        g.drawString("s",605,205);
        g.drawString("t",607,225);


        g.drawString("Start",45,242);
        g.drawString("Initialize",385,242);
        g.drawString("Adjust",745,242);
        g.drawString("Pink_Initialize",45,450);
        g.drawString("Pink_Adjust",385,450);
        g.drawString("End",600,600);



        blueToken.getShape().draw(g);

        for (pinkToken P : pinkToken_Start) {
            P.getShape().draw(g);
        }

        for (pinkToken P : pinkToken_gCS) {
            P.getShape().draw(g);
            String text = "[("+P.getVcConditionImpact().getVC()+", "+ P.getVcConditionImpact().getCondition()+", "+ P.getVcConditionImpact().getImpact()+")]";
            g.drawString("A",430,350);
            g.setFont(new Font("Arial", Font.BOLD, 15));
            g.drawString(text,280,400);
        }

        if(myflag==0)
        {
            g.setFont(new Font("Arial", Font.BOLD, 15));
            g.drawString("([],[],[],0, 0)",50,100);
        }

        if(myflag==1)
        {
            g.setFont(new Font("Arial", Font.BOLD, 15));
            g.drawString(TL.showBlueToken(blueToken),400,100);
        }

        if(myflag==2)
        {
            int in = TL.showBlueToken(blueToken).indexOf("]",22);
            int len =TL.showBlueToken(blueToken).length()-1;
            g.setFont(new Font("Arial", Font.BOLD, 15));
            g.drawString(TL.showBlueToken(blueToken).substring(0,in+1),635,80);
            g.drawString(TL.showBlueToken(blueToken).substring(in+2, len),635,100);
        }

        if(TL.myredflag==1)
        {

            g.setFont(new Font("Arial", Font.BOLD, 15));
            g.drawString("(1, (send, Inhibit send while connected, 0.2), 0.55, Adjust, 0.5)",500,550);

        }
        end.getShape().draw(g);
        rT1.getShape().draw(g);
        rT2.getShape().draw(g);


    }



}

