import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sharmin on 12/24/2017.
 */
public class vcChanges {

    private int IDConflict;
    private String VC;
    private double impact;

    public vcChanges(){}
    public vcChanges( int IDConflict, String VC,double impact)
    {
        this.IDConflict = IDConflict;
        this.VC = VC;
        this.impact =impact;
    }

    public int getIDConflict() {
        return IDConflict;
    }

    public String getVC() {
        return VC;
    }

    public double getImpact() {
        return impact;
    }
}
