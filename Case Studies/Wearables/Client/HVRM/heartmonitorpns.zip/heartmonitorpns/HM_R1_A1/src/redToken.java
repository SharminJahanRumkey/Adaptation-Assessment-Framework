import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * Created by Sharmin on 12/24/2017.
 */
public class redToken {
    private int ID;
    private int IDconflict;
    private vcInfo vcInfoList;
    private double p;
    private String conflictPlace;
    private double conflictPlacePredominance;
    private FilledCircle shape;
    private double utilityWeight;

    public redToken(int ID,int IDconflict,vcInfo vcInfoList,double p,String conflictPlace,double conflictPlacePredominance
                    ,double utilityWeight,int centerX, int centerY, int radius, Color color)
    {
        this.ID = ID;
        this.IDconflict =IDconflict;
        this.vcInfoList = vcInfoList;
        this.p = p;
        this.conflictPlace = conflictPlace;
        this.conflictPlacePredominance = conflictPlacePredominance;
        this.shape = new FilledCircle(centerX,centerY,radius,color);
        this.shape.setVisible(false);
        this.utilityWeight=utilityWeight;
    }

    public int getID() {
        return ID;
    }

    public int getIDconflict() {
        return IDconflict;
    }

    public vcInfo getVcInfoList() {
        return vcInfoList;
    }

    public double getP() {
        return p;
    }

    public String getConflictPlace() {
        return conflictPlace;
    }

    public double getConflictPlacePredominance() {
        return conflictPlacePredominance;
    }
    public FilledCircle getShape() {
        return shape;
    }



    public void setID(int id){this.ID=id;}
    public void setIDconflict(int id){this.IDconflict=id;}

    public void setP(double p) {
        this.p = p;
    }

    public void setConflictPlace(String conflictPlace) {
        this.conflictPlace = conflictPlace;
    }

    public void setConflictPlacePredominance(double conflictPlacePredominance) {
        this.conflictPlacePredominance = conflictPlacePredominance;
    }

    public void setVcInfoList(vcInfo vcInfoList) {
        this.vcInfoList = vcInfoList;
    }

    public void setUtilityWeight(double utilityWeight)
    {
        this.utilityWeight=utilityWeight;
    }
    public double getUtilityWeight()
    {
        return this.utilityWeight;
    }
}
