import com.sun.org.apache.xerces.internal.xs.StringList;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sharmin on 12/24/2017.
 */
public class pathDependency {
    private String VC;
    private List<String> dependentVCList;

    public pathDependency(String VC, List<String> dependentVCList)
    {
        this.VC = VC;
        this.dependentVCList = dependentVCList;
    }

    public String getVC() { return VC;}

    public List<String> getDependentVCList(){ return  this.dependentVCList;}
}
