import com.sun.org.apache.xerces.internal.xs.StringList;

import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * Created by Sharmin on 12/24/2017.
 */
public class Transition {
    private String name;
    private String[] inputPlaceList;
    private String[] outputPlaceList;
    private double impactMultiplier;
    private List<vcInfo> vcInfoList = new ArrayList<vcInfo>();
    private List<pathDependency> pathDependencyList = new ArrayList<pathDependency>();
    private Rectangle shape;
    private boolean isActive;
    private double utilityWeight;



    public Transition(String name, String[] inputPlaceList, String[] outputPlaceList,
                      double impactMultiplier, List<vcInfo> vcInfoList, List<pathDependency> pathDependencyList,
                      double utilityWeight,int x, int y, int height, int width, Color color)
    {
        this.name = name;
        this.inputPlaceList =inputPlaceList;
        this.outputPlaceList = outputPlaceList;
        this.impactMultiplier =impactMultiplier;
        this.vcInfoList = vcInfoList;
        this.pathDependencyList = pathDependencyList;
        this.shape = new Rectangle(x, y, height,width,color);
        this.isActive=false;
        this.utilityWeight=utilityWeight;

    }

    public String getName(){ return this.name;}

    public String[] getInputPlaceList() { return this.inputPlaceList;}

    public String[] getOutputPlaceList() { return this.outputPlaceList;}

    public double getImpactMultiplier() { return this.impactMultiplier;}

    public List<vcInfo> getVcInfoList() { return this.vcInfoList;}

    public List<pathDependency> getPathDependencyList() { return pathDependencyList;}

    public Rectangle getShape() { return shape;}

    public void setActive(boolean isActive)
    {
        this.isActive=isActive;
    }

    public boolean getActive(){ return this.isActive;}

    public double getUtilityWeight() { return this.utilityWeight;}

}
