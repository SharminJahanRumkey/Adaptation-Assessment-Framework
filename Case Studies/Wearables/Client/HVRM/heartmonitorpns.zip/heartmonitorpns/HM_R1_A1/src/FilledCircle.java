import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.util.Random;
public class FilledCircle
{
    private int centerX, centerY, radius;
    private Color color;
    private int direction, velocity;

    public FilledCircle(int x, int y, int r, Color c)
    {
        centerX = x;
        centerY = y;
        radius = r;
        color = c;
        direction = 0;
        velocity = 0;
    }

    public void draw(Graphics g)
    {
        Color oldColor = g.getColor();
        g.setColor(color);
            g.fillOval(centerX - radius, centerY - radius, radius * 2, radius * 2);
        g.setColor(oldColor);
    }

    public void fill(Graphics g)
    {
        Color oldColor = g.getColor();
        g.setColor(color);
        g.fillOval(centerX - radius, centerY - radius, radius * 2, radius * 2);
        g.setColor(oldColor);
    }

    public boolean containsPoint(int x, int y)
    {
        int xSquared = (x - centerX) * (x - centerX);
        int ySquared = (y - centerY) * (y - centerY);
        int radiusSquared = radius * radius;
        return xSquared + ySquared - radiusSquared <= 0;
    }

    public void move(int xAmount, int yAmount)
    {
        centerX = centerX + xAmount;
        centerY = centerY + yAmount;
    }

    public int getRadius()
    {
        return radius;
    }

    public int getX()
    {
        return centerX;
    }

    public int getY()
    {
        return centerY;
    }

    public int getDirection()
    {
        return direction;
    }

    public void setVelocity(int v)
    {
        velocity = v;
    }

    public int getVelocity()
    {
        return velocity;
    }

    public void setDirection(int d)
    {
        direction = d % 360;
    }

    public void turn(int degrees)
    {
        direction = (direction + degrees) % 360;
    }

    // Moves the circle in the current direction using its
    // current velocity
    public void move()
    {
        move((int)(velocity * Math.cos(Math.toRadians(direction))),
                (int)(velocity * Math.sin(Math.toRadians(direction))));
    }
    public void setCenterX(int x)
    {
        this.centerX=x;
    }

    public void setCenterY(int y){ this.centerY=y; }

    public void setVisible(boolean visible)
    {
       if(visible==true)
       {
           this.color=Color.red;
       }

    }
}