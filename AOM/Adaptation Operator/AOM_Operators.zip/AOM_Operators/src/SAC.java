import SACInstance.*;

public class SAC {
    public static void main(String[] args) {
        InstantiateSAC sac = new InstantiateSAC("r.xml");
        sac.loadXML();
    }
}
