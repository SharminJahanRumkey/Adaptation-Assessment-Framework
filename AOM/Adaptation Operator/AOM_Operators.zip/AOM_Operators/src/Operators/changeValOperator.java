package Operators;

import SACInstance.*;
import GSN.Context;
import GSN.OppGoal;
import Planner.Changes;
import Planner.Impact;

import java.util.List;

public class changeValOperator {

    private InstantiateSAC assuranceCaseInstance;
    private List<Impact> impactTableList;


    public changeValOperator(InstantiateSAC assuranceCaseInstance,List<Impact> impactTableList) {
        this.assuranceCaseInstance = assuranceCaseInstance;
        this.impactTableList = impactTableList;
    }

    public void EvoluteSACInstance(Changes changes) {
        if (changes.getOperatorType().equals("ChangeVal")) {
            String stVar = changes.getStateVar().trim();
            String newSt = changes.getNewState().trim();
            double impact = -1.0;

            for (Impact impactTable : this.impactTableList) {
                String prov = impactTable.getProvision().trim();
                String cond = impactTable.getCondition().trim();

                if (prov.equals(stVar) && cond.equals(newSt)) {
                    impact = impactTable.getImpact();
                    break;
                }
            }

            for (Context context : this.assuranceCaseInstance.getContexts()) {
                if (!context.getTailoring().equals("")) {
                    String tailoringVal = context.getTailoring().trim();
                    String[] Vars = tailoringVal.split(":");
                    if (Vars[0].equals(stVar)) {
                        context.setTailoring(Vars[0] + ":" + changes.getNewState());
                        break;
                    }
                }
            }

            for (OppGoal oppGoal : this.assuranceCaseInstance.getOppGoals()) {
                if (oppGoal.getVariable().equals(stVar)) {
                    if (impact >= 0.0) {
                        oppGoal.setCondition(newSt);
                        oppGoal.setAchievementWeight(String.valueOf(impact));
                    }
                }
            }
        }
    }


}

